from brain_games.brain_even_body import body


def main():
    body()


if __name__ == '__main__':
    main()
